package com.example.kpjmainho1;

import com.example.kpjmainho1.model.ServiceEvent;
import com.example.kpjmainho1.model.ServiceRepository;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.time.OffsetDateTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@SpringBootTest
public class ServiceEventTest{
    @Autowired
    ServiceRepository serviceRepository;

    @AfterEach
    public void cleanUp(){
        serviceRepository.deleteAll();
    }

    @Test
    void testSaveAndFindByName(){
        ServiceEvent serviceEvent = new ServiceEvent();
        serviceEvent.setName("testservice");
        serviceEvent.setPort("88");
        serviceEvent.setRegisterTime(OffsetDateTime.now());
        serviceRepository.save(serviceEvent);
        assertNotNull(serviceRepository.findByName("testservice"));
    }

    @Test
    public void testSaveAndFindAll(){
        ServiceEvent serviceEvent = new ServiceEvent();
        serviceEvent.setName("kpj.testservice");
        serviceEvent.setPort("8080");
        serviceEvent.setRegisterTime(OffsetDateTime.now());
        serviceRepository.save(serviceEvent);

        List<ServiceEvent> serviceEvents = serviceRepository.findAll();
        assertFalse(serviceEvents.isEmpty());
        assertNotNull(serviceEvents.get(0));
    }

}
