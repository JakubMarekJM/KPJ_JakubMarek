package com.example.kpjmainho1.openapi.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import java.time.OffsetDateTime;
import java.util.Objects;
import javax.validation.Valid;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;

public class ServiceDTO {
    @JsonProperty("id")
    private Long id;
    @JsonProperty("name")
    private String name;
    @JsonProperty("port")
    private String port;
    @JsonProperty("registerTime")
    @DateTimeFormat(
            iso = ISO.DATE_TIME
    )
    private OffsetDateTime registerTime;

    public ServiceDTO() {
    }

    public ServiceDTO id(Long id) {
        this.id = id;
        return this;
    }

    @Schema(
            name = "id",
            required = false
    )
    public Long getId() {
        return this.id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public ServiceDTO name(String name) {
        this.name = name;
        return this;
    }

    @Schema(
            name = "name",
            required = false
    )
    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ServiceDTO port(String port) {
        this.port = port;
        return this;
    }

    @Schema(
            name = "port",
            required = false
    )
    public String getPort() {
        return this.port;
    }

    public void setPort(String port) {
        this.port = port;
    }

    public ServiceDTO registerTime(OffsetDateTime registerTime) {
        this.registerTime = registerTime;
        return this;
    }

    @Schema(
            name = "registerTime",
            required = false
    )
    public @Valid OffsetDateTime getRegisterTime() {
        return this.registerTime;
    }

    public void setRegisterTime(OffsetDateTime registerTime) {
        this.registerTime = registerTime;
    }

    public boolean equals(Object o) {
        if (this == o) {
            return true;
        } else if (o != null && this.getClass() == o.getClass()) {
            ServiceDTO serviceDTO = (ServiceDTO)o;
            return Objects.equals(this.id, serviceDTO.id) && Objects.equals(this.name, serviceDTO.name) && Objects.equals(this.port, serviceDTO.port) && Objects.equals(this.registerTime, serviceDTO.registerTime);
        } else {
            return false;
        }
    }

    public int hashCode() {
        return Objects.hash(new Object[]{this.id, this.name, this.port, this.registerTime});
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("class ServiceDTO {\n");
        sb.append("    id: ").append(this.toIndentedString(this.id)).append("\n");
        sb.append("    name: ").append(this.toIndentedString(this.name)).append("\n");
        sb.append("    port: ").append(this.toIndentedString(this.port)).append("\n");
        sb.append("    registerTime: ").append(this.toIndentedString(this.registerTime)).append("\n");
        sb.append("}");
        return sb.toString();
    }

    private String toIndentedString(Object o) {
        return o == null ? "null" : o.toString().replace("\n", "\n    ");
    }
}
