package com.example.kpjmainho1.controller;

import com.example.kpjmainho1.mapper.ServiceMapper;
import com.example.kpjmainho1.messaging.KpjProducer;
import com.example.kpjmainho1.model.ServiceEvent;
import com.example.kpjmainho1.model.ServiceRepository;
import com.example.kpjmainho1.openapi.model.ServiceDTO;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import javax.annotation.PostConstruct;
import java.util.List;
import java.util.stream.Collectors;

@RequiredArgsConstructor
@RestController
@RequestMapping(path = "/services/")
public class ApplicationRestController {

    @Autowired
    private ServiceRepository serviceRepository;
    @Autowired
    private ServiceMapper serviceMapper;
    @Autowired
    private KpjProducer kpjProducer;

    @Value("${serviceName}")
    private String serviceName;

    @PostConstruct
    private void init()  {

    }

    @PostMapping("/register")
    public void registerNewService() {

        kpjProducer.sendMessage();

    }

    @GetMapping("/")
    public List<ServiceDTO> listServiceEvents(){
        return serviceRepository.findAll().stream().map(this::toServiceDTO).collect(Collectors.toList());
    }

    @GetMapping(value = "/{name}")
    public ServiceDTO getServiceEventInfoByName (@PathVariable String name) {
        if (serviceRepository.existsByName(name)) {
            ServiceDTO serviceDTO = serviceMapper.serviceEventToServiceDTO(serviceRepository.findByName(name));
            return serviceDTO;
        }else throw new ResponseStatusException(HttpStatus.NOT_FOUND);
    }

    @GetMapping("/current")
    public ServiceDTO getCurrentService(){
        ServiceDTO serviceDTO = serviceMapper.serviceEventToServiceDTO(serviceRepository.findByName(serviceName));
        return serviceDTO;
    }

    private ServiceDTO toServiceDTO(ServiceEvent serviceEvent){
        ServiceDTO serviceDTO = serviceMapper.serviceEventToServiceDTO(serviceEvent);
        return serviceDTO;
    }

    private ServiceEvent toServiceEvent(ServiceDTO serviceDTO){
        ServiceEvent serviceEvent = serviceMapper.serviceDTOToServiceEvent(serviceDTO);
        return serviceEvent;
    }
}
