package com.example.kpjmainho1.messaging;

import com.example.kpjmainho1.model.ServiceEvent;
import com.example.kpjmainho1.model.ServiceRepository;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.OffsetDateTime;

@Service
public class KpjConsumer {

    @Autowired
    private ServiceRepository serviceRepository;

    @Autowired
    private KpjProducer kpjProducer;

    @RabbitListener(queues = "kpj.jakubmarek")
    public void listenQeue(String message){
        String [] split = message.split(";");
        String nameIn = split[0];
        String portIn = split[1];
        if (!serviceRepository.existsByName(nameIn)) {
            ServiceEvent serviceEvent = new ServiceEvent();
            serviceEvent.setName(nameIn);
            serviceEvent.setPort(portIn);
            serviceEvent.setRegisterTime(OffsetDateTime.now());
            serviceRepository.save(serviceEvent);
            kpjProducer.sendMessage();
        }
    }
}
