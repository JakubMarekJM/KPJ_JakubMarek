package com.example.kpjmainho1.messaging;

import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class KpjProducer {
    @Autowired
    private RabbitTemplate rabbitTemplate;

    @Value("${serviceName}")
    private String serviceName;

    @Value("${servicePort}")
    private String servicePort;

    @Value("${exchangeName}")
    private String exchangeName;

    public void sendMessage()  {
        String message = serviceName + ";" + servicePort;
        rabbitTemplate.convertAndSend(exchangeName, "", message);
    }
}
