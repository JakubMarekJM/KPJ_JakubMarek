package com.example.kpjmainho1.config;

import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.FanoutExchange;
import org.springframework.amqp.core.Queue;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RabbitmqConfig {

    @Bean
    public FanoutExchange fanoutExchange(){
        return new FanoutExchange("kpj");
    }

    @Bean
    public Queue queue(){
        return new Queue("kpj.jakubmarek");
    }

    @Bean
    public Binding binding(FanoutExchange fanoutExchange, Queue queue){
        return BindingBuilder.bind(queue).to(fanoutExchange);
    }

}
