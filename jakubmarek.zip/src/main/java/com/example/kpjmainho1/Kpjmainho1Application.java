package com.example.kpjmainho1;

import com.example.kpjmainho1.messaging.KpjProducer;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.annotation.EnableRabbit;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
@EnableRabbit
@Slf4j
public class Kpjmainho1Application implements CommandLineRunner {

    @Autowired
    private KpjProducer kpjProducer;

    public static void main(String[] args) {
        SpringApplication.run(Kpjmainho1Application.class, args);
    }

    @Override
    public void run(String... args) throws Exception {
        kpjProducer.sendMessage();
    }
}
