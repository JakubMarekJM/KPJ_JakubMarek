package com.example.kpjmainho1.model;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ServiceRepository extends JpaRepository<ServiceEvent, Long> {

    ServiceEvent findByName(String name);

    boolean existsByName(String name);
}
