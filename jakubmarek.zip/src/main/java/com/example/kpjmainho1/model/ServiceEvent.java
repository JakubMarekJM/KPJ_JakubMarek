package com.example.kpjmainho1.model;

import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import java.time.OffsetDateTime;

@Data
@NoArgsConstructor
@Entity
public class ServiceEvent {
    @Id
    @GeneratedValue
    private Long id;

    private String name;

    private String port;

    //@DateTimeFormat(iso = ISO.DATE_TIME)
    private OffsetDateTime registerTime;
}
