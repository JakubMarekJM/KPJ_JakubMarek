package com.example.kpjmainho1.mapper;

import com.example.kpjmainho1.model.ServiceEvent;
import com.example.kpjmainho1.openapi.model.ServiceDTO;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper(componentModel = "spring")
public interface ServiceMapper {

    ServiceMapper INSTANCE = Mappers.getMapper(ServiceMapper.class);
    ServiceDTO serviceEventToServiceDTO(ServiceEvent serviceEvent);
    @InheritInverseConfiguration
    ServiceEvent serviceDTOToServiceEvent (ServiceDTO serviceDTO);
}
