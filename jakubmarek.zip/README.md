# KPJ homework
# Jakub Marek

Prerequisities
- Docker is running

1. Run `mvn clean install`
   - Docker image is created
2. Run `docker-compose up -d`
   - service is active on localhost with port `30214`